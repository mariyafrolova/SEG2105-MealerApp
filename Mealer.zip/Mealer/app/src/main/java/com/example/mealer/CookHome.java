package com.example.mealer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CookHome extends AppCompatActivity {
    EditText name, type, cuisine, ingredients, allergens, price, description;
    Button add, profile, meals, orders;
    DatabaseHelper mydb;
    String cook_id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cook_home);

        name = findViewById(R.id.name);
        type = findViewById(R.id.type);
        cuisine = findViewById(R.id.cuisine);
        ingredients = findViewById(R.id.ingredients);
        allergens = findViewById(R.id.allergens);
        price = findViewById(R.id.price);
        description = findViewById(R.id.description);
        add = findViewById(R.id.add);
        profile = findViewById(R.id.profile);
        meals = findViewById(R.id.meals);
        orders = findViewById(R.id.orders);
        mydb = new DatabaseHelper(this);

        SharedPreferences sharedPrefUser = getSharedPreferences("cookData", MODE_PRIVATE);
        cook_id = sharedPrefUser.getString("cook_id", "");
        meals.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(CookHome.this, CookMeals.class));
            }
        });
        orders.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(CookHome.this, CookOrdersActivity.class));
            }
        });
        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(CookHome.this, CookProfile.class));
            }
        });

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String getName = name.getText().toString();
                String getType = type.getText().toString();
                String getCuisine = cuisine.getText().toString();
                String getIngredients = ingredients.getText().toString();
                String getAllergens = allergens.getText().toString();
                String getPrice = price.getText().toString();
                String getDescription = description.getText().toString();
                if (!getName.equals("") && !getType.equals("") && !getCuisine.equals("") && !getIngredients.equals("") && !getAllergens.equals("") && !getPrice.equals("") && !getDescription.equals("")){
                    mydb.insertDataMeal(cook_id, getName, getType, getCuisine, getIngredients, getAllergens, getPrice, getDescription);
                    Toast.makeText(getApplicationContext(), "Meal Added Successfully", Toast.LENGTH_SHORT).show();
                    name.setText("");
                    type.setText("");
                    cuisine.setText("");
                    ingredients.setText("");
                    allergens.setText("");
                    price.setText("");
                    description.setText("");

                }else{
                    Toast.makeText(getApplicationContext(), "All fields are required!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}