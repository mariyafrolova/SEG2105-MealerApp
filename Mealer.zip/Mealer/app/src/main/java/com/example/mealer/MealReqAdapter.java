package com.example.mealer;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MealReqAdapter extends RecyclerView.Adapter<MealReqAdapter.Myclass>{
    Context context;
    ArrayList<GetterSetterOrder> al;
    DatabaseHelper mydb;

    public MealReqAdapter(Context context, ArrayList<GetterSetterOrder> al){
        this.context = context;
        this.al = al;
    }
    @NonNull
    @Override
    public Myclass onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.rowfile_meal_requested,viewGroup,false);
        return new Myclass(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final Myclass myclass, int i) {
        final GetterSetterOrder gl = al.get(i);
        mydb = new DatabaseHelper(context);
        myclass.cook_id.setText("Cook Name: " + mydb.getCookName(gl.getCook_id()));
        myclass.meal_id.setText("Meal Id: " + gl.getMeal_id());
        myclass.pickup_time.setText("Pickup Time: " + gl.getPickup_time());
        myclass.status.setText("Status: " + gl.getStatus());


    }

    @Override
    public int getItemCount() {
        return al.size();
    }
    public class Myclass extends RecyclerView.ViewHolder{

        TextView cook_id,meal_id,pickup_time, status;
        View mview;

        public Myclass(@NonNull View itemView) {
            super(itemView);
            cook_id = itemView.findViewById(R.id.cook_id);
            meal_id  = itemView.findViewById(R.id.meal_id);
            pickup_time  = itemView.findViewById(R.id.pickup_time);
            status  = itemView.findViewById(R.id.status);
            mview = itemView;
        }
    }
}
