package com.example.mealer;

import static android.content.Context.MODE_PRIVATE;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AdminComplainAdapter extends RecyclerView.Adapter<AdminComplainAdapter.Myclass>{
    Context context;
    ArrayList<GetterSetterComplain> al;
    DatabaseHelper mydb;

    public AdminComplainAdapter(Context context, ArrayList<GetterSetterComplain> al){
        this.context = context;
        this.al = al;
    }
    @NonNull
    @Override
    public Myclass onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.rowfile_admin_complain,viewGroup,false);
        return new Myclass(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final Myclass myclass, int i) {
        final GetterSetterComplain gl = al.get(i);
        mydb = new DatabaseHelper(context);
        myclass.client_id.setText("Client Name: " + mydb.getClientName(gl.getClient_id()));
        myclass.cook_id.setText("Cook Id: " + mydb.getCookName(gl.getCook_id()));
        myclass.complain.setText("Complain: " + gl.getComplain());

        myclass.dismiss.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mydb = new DatabaseHelper(context);
                mydb.dismissComplain(gl.getId());
                Toast.makeText(context, "Complain dismissed successfully", Toast.LENGTH_SHORT).show();
            }
        });
        myclass.suspend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mydb = new DatabaseHelper(context);
                mydb.suspendCook(gl.getId());
                Toast.makeText(context, "Cook suspended successfully", Toast.LENGTH_SHORT).show();
            }
        });


    }

    @Override
    public int getItemCount() {
        return al.size();
    }
    public class Myclass extends RecyclerView.ViewHolder{

        TextView cook_id,client_id,complain;
        Button dismiss, suspend;
        View mview;

        public Myclass(@NonNull View itemView) {
            super(itemView);
            cook_id = itemView.findViewById(R.id.cook_id);
            client_id = itemView.findViewById(R.id.client_id);
            complain = itemView.findViewById(R.id.complain);
            dismiss  = itemView.findViewById(R.id.dismiss);
            suspend  = itemView.findViewById(R.id.suspend);
            mview = itemView;
        }
    }
}
