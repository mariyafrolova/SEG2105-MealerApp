package com.example.mealer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterClient extends AppCompatActivity {
    EditText f_name, l_name, email, password, address, cc_info;
    Button register;
    DatabaseHelper mydb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_client);
        f_name = findViewById(R.id.f_name);
        l_name = findViewById(R.id.l_name);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        address = findViewById(R.id.address);
        cc_info = findViewById(R.id.cc_info);
        register = findViewById(R.id.register);

        mydb = new DatabaseHelper(this);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String getFName = f_name.getText().toString();
                String getLName = l_name.getText().toString();
                String getEmail = email.getText().toString();
                String getPassword = password.getText().toString();
                String getAddress = address.getText().toString();
                String getCCInfo = cc_info.getText().toString();
                if (!getFName.equals("")){
                    if (!getLName.equals("")){
                        if (!getEmail.equals("")){
                            if (!getPassword.equals("")){
                                if (!getAddress.equals("")){
                                    if (!getCCInfo.equals("")){
                                        mydb.insertDataClient(getFName,getLName, getEmail, getPassword, getAddress, getCCInfo);
                                        Toast.makeText(getApplicationContext(), "Client Registered Successfully", Toast.LENGTH_SHORT).show();
                                        startActivity(new Intent(RegisterClient.this, MainActivity.class));

                                    }else{
                                        Toast.makeText(getApplicationContext(), "Credit Card Info cannot be empty!", Toast.LENGTH_SHORT).show();
                                    }

                                }else{
                                    Toast.makeText(getApplicationContext(), "Address cannot be empty!", Toast.LENGTH_SHORT).show();
                                }

                            }else{
                                Toast.makeText(getApplicationContext(), "Password cannot be empty!", Toast.LENGTH_SHORT).show();
                            }

                        }else{
                            Toast.makeText(getApplicationContext(), "Email cannot be empty!", Toast.LENGTH_SHORT).show();
                        }

                    }else{
                        Toast.makeText(getApplicationContext(), "Last Name cannot be empty!", Toast.LENGTH_SHORT).show();
                    }

                }else{
                    Toast.makeText(getApplicationContext(), "First Name cannot be empty!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}