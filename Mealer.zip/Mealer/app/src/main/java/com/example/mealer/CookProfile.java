package com.example.mealer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.widget.ImageView;
import android.widget.TextView;

public class CookProfile extends AppCompatActivity {
    TextView cook_id, f_name, l_name, email, password, address, description, status, rating, meal_sold;
    ImageView imageView;
    DatabaseHelper mydb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cook_profile);

        mydb = new DatabaseHelper(this);

        cook_id = findViewById(R.id.cook_id);
        f_name = findViewById(R.id.f_name);
        l_name = findViewById(R.id.l_name);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        address = findViewById(R.id.address);
        description = findViewById(R.id.description);
        status = findViewById(R.id.status);
        rating = findViewById(R.id.rating);
        meal_sold = findViewById(R.id.meal_sold);
        imageView = findViewById(R.id.imageView);

        SharedPreferences sharedPrefUser = getSharedPreferences("cookData", MODE_PRIVATE);
        String getcook_id = sharedPrefUser.getString("cook_id", "");
        String getf_name = sharedPrefUser.getString("f_name", "");
        String getl_name = sharedPrefUser.getString("l_name", "");
        String getemail = sharedPrefUser.getString("email", "");
        String getpassword = sharedPrefUser.getString("password", "");
        String getaddress = sharedPrefUser.getString("address", "");
        String getdescription = sharedPrefUser.getString("description", "");
        String getcheque = sharedPrefUser.getString("cheque", "");
        String getstatus = sharedPrefUser.getString("status", "");

        cook_id.setText("Cook ID: " + getcook_id);
        f_name.setText("First Name: " + getf_name);
        l_name.setText("Last Name: " + getl_name);
        email.setText("Email Address: " + getemail);
        password.setText("Password: " + getpassword);
        address.setText("Address: " + getaddress);
        description.setText("Description: " + getdescription);
        status.setText("Status: " + getstatus);
        rating.setText("Rating: " + mydb.getRating(getcook_id));
        meal_sold.setText("Number of Meal Sold: " + mydb.getMealsSold(getcook_id));


        final byte[] decodedString = Base64.decode(getcheque, Base64.DEFAULT);
        Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
        imageView.setImageBitmap(decodedByte);
    }
}