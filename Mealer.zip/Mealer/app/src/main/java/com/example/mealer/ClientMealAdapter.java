package com.example.mealer;

import static android.content.Context.MODE_PRIVATE;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ClientMealAdapter extends RecyclerView.Adapter<ClientMealAdapter.Myclass>{
    Context context;
    ArrayList<GetterSetterMeal> al;
    DatabaseHelper mydb;

    public ClientMealAdapter(Context context, ArrayList<GetterSetterMeal> al){
        this.context = context;
        this.al = al;
    }
    @NonNull
    @Override
    public Myclass onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.rowfile_cmeal,viewGroup,false);
        return new Myclass(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final Myclass myclass, int i) {
        final GetterSetterMeal gl = al.get(i);

        myclass.name.setText("Meal Name: " + gl.getName());
        myclass.type.setText("Meal Type: " + gl.getType());
        myclass.cuisine.setText("Cuisine Type: " + gl.getCuisine());
        myclass.ingredients.setText("Ingredients: " + gl.getIngredient());
        myclass.allergens.setText("Allergens: " + gl.getAllergen());
        myclass.price.setText("Price: $"+gl.getPrice());
        myclass.description.setText("Description: " + gl.getDescription());



        myclass.order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences.Editor nameEditor = context.getSharedPreferences("orderData", MODE_PRIVATE).edit();
                nameEditor.putString("cook_id", gl.getCook_id());
                nameEditor.putString("meal_id", gl.getId());
                nameEditor.apply();
                v.getContext().startActivity(new Intent(context, OrderActivity.class));
            }
        });
        myclass.view_cook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences.Editor nameEditor = context.getSharedPreferences("viewCookData", MODE_PRIVATE).edit();
                nameEditor.putString("cook_id", gl.getCook_id());
                nameEditor.apply();
                v.getContext().startActivity(new Intent(context, ViewCookActivity.class));
            }
        });


    }

    @Override
    public int getItemCount() {
        return al.size();
    }
    public class Myclass extends RecyclerView.ViewHolder{

        TextView name,type,cuisine, ingredients, allergens, price, description;
        Button order, view_cook;
        View mview;

        public Myclass(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.name);
            type  = itemView.findViewById(R.id.type);
            cuisine  = itemView.findViewById(R.id.cuisine);
            ingredients  = itemView.findViewById(R.id.ingredients);
            allergens  = itemView.findViewById(R.id.allergens);
            price  = itemView.findViewById(R.id.price);
            description  = itemView.findViewById(R.id.description);
            view_cook  = itemView.findViewById(R.id.view_cook);
            order  = itemView.findViewById(R.id.order);
            mview = itemView;
        }
    }
}
