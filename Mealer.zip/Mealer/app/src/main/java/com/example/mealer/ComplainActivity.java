package com.example.mealer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ComplainActivity extends AppCompatActivity {
    EditText complain;
    Button btn_complain;
    DatabaseHelper mydb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complain);

        complain = findViewById(R.id.complain);
        btn_complain = findViewById(R.id.btn_complain);

        mydb = new DatabaseHelper(this);

        SharedPreferences sharedPrefUser = getSharedPreferences("clientData", MODE_PRIVATE);
        String client_id = sharedPrefUser.getString("client_id", "");
        SharedPreferences sharedPreforder = getSharedPreferences("complainData", MODE_PRIVATE);
        String cook_id = sharedPreforder.getString("cook_id", "");

        btn_complain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String getComplain = complain.getText().toString();
                if (!getComplain.equals("")){
                    mydb.insertDataComplain(client_id, cook_id, getComplain);
                    Toast.makeText(getApplicationContext(), "Complain submitted successfully", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(getApplicationContext(), "Complain is required", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}