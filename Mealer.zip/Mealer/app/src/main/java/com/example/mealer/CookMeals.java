package com.example.mealer;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;

public class CookMeals extends AppCompatActivity {
    RecyclerView rv;
    ArrayList<GetterSetterMeal> al = new ArrayList<>();
    DatabaseHelper mydb;
    String cook_id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cook_meals);
        rv = findViewById(R.id.rev);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        rv.setLayoutManager(layoutManager);
        SharedPreferences sharedPrefUser = getSharedPreferences("cookData", MODE_PRIVATE);
        cook_id = sharedPrefUser.getString("cook_id", "");
        viewData(cook_id);
    }
    private void viewData(String cook_id){

        mydb = new DatabaseHelper(getApplicationContext());
        Cursor c = mydb.viewCookMeals(cook_id);
        if (c.getCount() > 0) {
            if (c.moveToFirst()) {
                do {

                    String id = c.getString(0);
                    String c_id = c.getString(1);
                    String name = c.getString(2);
                    String type = c.getString(3);
                    String cuisine = c.getString(4);
                    String ingredient = c.getString(5);
                    String allergen = c.getString(6);
                    String price = c.getString(7);
                    String description = c.getString(8);

                    GetterSetterMeal gl = new GetterSetterMeal(id,c_id, name, type, cuisine, ingredient, allergen, price, description);
                    al.add(gl);

                } while (c.moveToNext());
            }
        }else{
            Toast.makeText(getApplicationContext(), "No meal added", Toast.LENGTH_SHORT).show();
        }
        CookMealAdapter my = new CookMealAdapter(getApplicationContext(), al);
        rv.setAdapter(my);
    }
}