package com.example.mealer;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;

public class AdminHome extends AppCompatActivity {
    RecyclerView rv;
    ArrayList<GetterSetterComplain> al;
    DatabaseHelper mydb;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_home);
        rv = findViewById(R.id.rev);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        rv.setLayoutManager(layoutManager);
        viewData();
    }
    private void viewData(){
        mydb = new DatabaseHelper(getApplicationContext());
        al = new ArrayList<>();
        Cursor c = mydb.viewComplains();
        if (c.getCount() > 0) {
            if (c.moveToFirst()) {
                do {

                    String id = c.getString(0);
                    String client_id = c.getString(1);
                    String cook_id = c.getString(2);
                    String complain = c.getString(3);

                    GetterSetterComplain gl = new GetterSetterComplain(id,client_id, cook_id, complain);
                    al.add(gl);

                } while (c.moveToNext());
            }
        }else{
            Toast.makeText(getApplicationContext(), "No complain found", Toast.LENGTH_SHORT).show();
        }
        AdminComplainAdapter my = new AdminComplainAdapter(getApplicationContext(), al);
        rv.setAdapter(my);
    }
}