package com.example.mealer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RateActivity extends AppCompatActivity {
    EditText rating;
    Button btn_rate;
    DatabaseHelper mydb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rate);

        rating = findViewById(R.id.rate);
        btn_rate = findViewById(R.id.btn_rate);

        mydb = new DatabaseHelper(this);

        SharedPreferences sharedPrefUser = getSharedPreferences("clientData", MODE_PRIVATE);
        String client_id = sharedPrefUser.getString("client_id", "");

        SharedPreferences sharedPreforder = getSharedPreferences("rateData", MODE_PRIVATE);
        String cook_id = sharedPreforder.getString("cook_id", "");
        String meal_id = sharedPreforder.getString("meal_id", "");

        btn_rate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String getRating = rating.getText().toString();
                if (!getRating.equals("")){
                    mydb.insertDataRating(cook_id, meal_id, getRating);
                    Toast.makeText(getApplicationContext(), "Rating submitted successfully", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(getApplicationContext(), "Rating is required", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}