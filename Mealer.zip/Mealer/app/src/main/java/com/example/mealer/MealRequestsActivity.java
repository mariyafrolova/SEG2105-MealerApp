package com.example.mealer;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;

public class MealRequestsActivity extends AppCompatActivity {

    RecyclerView rv;
    ArrayList<GetterSetterOrder> al;
    DatabaseHelper mydb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meal_requests);
        rv = findViewById(R.id.rev);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        rv.setLayoutManager(layoutManager);
        SharedPreferences sharedPrefUser = getSharedPreferences("clientData", MODE_PRIVATE);
        String client_id = sharedPrefUser.getString("client_id", "");
        viewData(client_id);
    }
    private void viewData(String client_id){
        mydb = new DatabaseHelper(getApplicationContext());
        al = new ArrayList<>();
        Cursor c = mydb.viewMealsRequested(client_id);
        if (c.getCount() > 0) {
            if (c.moveToFirst()) {
                do {

                    String id = c.getString(0);
                    String c_id = c.getString(1);
                    String cook_id = c.getString(2);
                    String meal_id = c.getString(3);
                    String pickup_time = c.getString(4);
                    String status = c.getString(5);

                    GetterSetterOrder gl = new GetterSetterOrder(id,c_id, cook_id, meal_id, pickup_time, status);
                    al.add(gl);

                } while (c.moveToNext());
            }
        }else{
            Toast.makeText(getApplicationContext(), "No meal requested", Toast.LENGTH_SHORT).show();
        }
        MealReqAdapter my = new MealReqAdapter(getApplicationContext(), al);
        rv.setAdapter(my);
    }
}