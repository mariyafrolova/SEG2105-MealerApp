package com.example.mealer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener{
    EditText email, password;
    Button clientRegister, cookRegister, login;
    Spinner role;
    String roleSelected;
    DatabaseHelper mydb;
    String id, f_name, l_name, address, cc_info, description, cheque, status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        login = findViewById(R.id.login);
        clientRegister = findViewById(R.id.clientRegister);
        cookRegister = findViewById(R.id.cookRegister);
        role = findViewById(R.id.role);
        role.setOnItemSelectedListener(this);
        List<String> roleList = new ArrayList<>();
        roleList.add("Client");
        roleList.add("Cook");
        roleList.add("Admin");
        ArrayAdapter<String> roleAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, roleList);
        roleAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        role.setAdapter(roleAdapter);
        role.setSelection(0);

        mydb = new DatabaseHelper(this);

        clientRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, RegisterClient.class));
            }
        });
        cookRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, RegisterCook.class));
            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String getEmail = email.getText().toString();
                String getPassword = password.getText().toString();
                if (!getEmail.equals("")){
                    if (!getPassword.equals("")){
                        if (roleSelected.equals("Client")){
                            Cursor c = mydb.clientLogin(getEmail, getPassword);
                            if (c.getCount() > 0) {
                                if (c.moveToFirst()) {
                                    do {

                                        id = c.getString(0);
                                        f_name = c.getString(1);
                                        l_name = c.getString(2);
                                        address = c.getString(5);
                                        cc_info = c.getString(6);

                                    } while (c.moveToNext());
                                }
                                SharedPreferences.Editor nameEditor = getSharedPreferences("clientData", MODE_PRIVATE).edit();
                                nameEditor.putString("client_id", id);
                                nameEditor.putString("f_name", f_name);
                                nameEditor.putString("l_name", l_name);
                                nameEditor.putString("email", getEmail);
                                nameEditor.putString("password", getPassword);
                                nameEditor.putString("address", address);
                                nameEditor.putString("cc_info", cc_info);
                                nameEditor.apply();
                                startActivity(new Intent(MainActivity.this, ClientHome.class));

                            }else{
                                Toast.makeText(getApplicationContext(), "Incorrect email or password!", Toast.LENGTH_SHORT).show();
                            }
                        }
                        else if (roleSelected.equals("Cook")){
                            Cursor c = mydb.cookLogin(getEmail, getPassword);

                            if (c.getCount() > 0) {
                                if (c.moveToFirst()) {
                                    do {

                                        id = c.getString(0);
                                        f_name = c.getString(1);
                                        l_name = c.getString(2);
                                        address = c.getString(5);
                                        description = c.getString(6);
                                        cheque = c.getString(7);
                                        status = c.getString(8);

                                    } while (c.moveToNext());
                                }
                                SharedPreferences.Editor nameEditor = getSharedPreferences("cookData", MODE_PRIVATE).edit();
                                nameEditor.putString("cook_id", id);
                                nameEditor.putString("f_name", f_name);
                                nameEditor.putString("l_name", l_name);
                                nameEditor.putString("email", getEmail);
                                nameEditor.putString("password", getPassword);
                                nameEditor.putString("address", address);
                                nameEditor.putString("description", description);
                                nameEditor.putString("cheque", cheque);
                                nameEditor.putString("status", status);
                                nameEditor.apply();
                                startActivity(new Intent(MainActivity.this, CookHome.class));

                            }else{
                                Toast.makeText(getApplicationContext(), "Incorrect email or password!", Toast.LENGTH_SHORT).show();
                            }
                        }
                        else if (roleSelected.equals("Admin")){
                            String adm_email = "l";
                            String adm_password = "l";

                            if (getEmail.equals(adm_email) && getPassword.equals(adm_password)){
                                startActivity(new Intent(MainActivity.this, AdminHome.class));
                            }else{
                                Toast.makeText(getApplicationContext(), "Incorrect email or password!", Toast.LENGTH_SHORT).show();
                            }

                        }
                    }else{
                        Toast.makeText(getApplicationContext(), "Password is required", Toast.LENGTH_SHORT).show();
                    }

                }else{
                    Toast.makeText(getApplicationContext(), "Email is required", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long l) {
        String item = parent.getItemAtPosition(position).toString();
        roleSelected = item;
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}