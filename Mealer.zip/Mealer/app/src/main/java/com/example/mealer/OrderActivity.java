package com.example.mealer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class OrderActivity extends AppCompatActivity {
    String client_id, cook_id, meal_id;
    EditText pickup_time;
    Button complete;
    DatabaseHelper mydb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);
        pickup_time = findViewById(R.id.pickup_time);
        complete = findViewById(R.id.complete);
        SharedPreferences sharedPrefUser = getSharedPreferences("clientData", MODE_PRIVATE);
        client_id = sharedPrefUser.getString("client_id", "");

        SharedPreferences sharedPreforder = getSharedPreferences("orderData", MODE_PRIVATE);
        cook_id = sharedPreforder.getString("cook_id", "");
        meal_id = sharedPreforder.getString("meal_id", "");

        mydb = new DatabaseHelper(this);

        complete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String getTime = pickup_time.getText().toString();
                if (!getTime.equals("")){
                    String status = "Pending";
                    mydb.insertDataOrder(client_id, cook_id, meal_id, getTime, status);
                    Toast.makeText(getApplicationContext(), "Order Placed Successfully", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(OrderActivity.this, ClientHome.class));
                }else{
                    Toast.makeText(getApplicationContext(), "pickup time is required", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}