package com.example.mealer;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "meal.db";
    private static final String DB_TABLE_CLIENT = "client";
    private static final String DB_TABLE_ADMIN = "admin";
    private static final String DB_TABLE_COOK = "cook";
    private static final String DB_TABLE_MEAL = "meal";
    private static final String DB_TABLE_ORDER = "orders";
    private static final String DB_TABLE_RATING = "rating";
    private static final String DB_TABLE_COMPLAIN = "complain";

    private static final String ID = "id";
    private static final String FIRST_NAME = "first_name";
    private static final String LAST_NAME = "last_name";
    private static final String EMAIL = "email";
    private static final String PASSWORD = "password";
    private static final String ADDRESS = "address";
    private static final String CC_INFO = "cc_info";
    private static final String CHEQUE = "cheque";
    private static final String DESCRIPTION = "description";
    private static final String STATUS = "status";

    private static final String NAME = "name";
    private static final String TYPE = "type";
    private static final String CUISINE = "cuisine";
    private static final String INGREDIENTS = "ingredients";
    private static final String ALLERGENS = "allergens";
    private static final String PRICE = "price";
    private static final String COOK_ID = "cook_id";
    private static final String MEAL_ID = "meal_id";
    private static final String CLIENT_ID = "client_id";
    private static final String RATING = "rating";
    private static final String PICKUP_TIME = "pickup_time";
    private static final String CLIENT = "client";
    private static final String COOK = "cook";
    private static final String COMPLAIN = "complain";

    int rating;
    int count;
    String name;
    int avg;

    public static final String CREATE_TABLE_CLIENT = "CREATE TABLE " + DB_TABLE_CLIENT + " (" +
            ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + FIRST_NAME + " TEXT," +
            LAST_NAME + " TEXT," + EMAIL + " TEXT," + PASSWORD + " TEXT," + ADDRESS + " TEXT," + CC_INFO + " TEXT" + ")";
    public static final String CREATE_TABLE_ADMIN = "CREATE TABLE " + DB_TABLE_ADMIN + " (" +
            ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + EMAIL + " TEXT," + PASSWORD + " TEXT" + ")";
    public static final String CREATE_TABLE_COOK = "CREATE TABLE " + DB_TABLE_COOK + " (" +
            ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + FIRST_NAME + " TEXT," +
            LAST_NAME + " TEXT," + EMAIL + " TEXT," + PASSWORD + " TEXT," + ADDRESS + " TEXT," +  DESCRIPTION + " TEXT," + CHEQUE + " TEXT, " + STATUS + " TEXT" + ")";
    public static final String CREATE_TABLE_MEAL = "CREATE TABLE " + DB_TABLE_MEAL + " (" +
            ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COOK_ID + " TEXT," + NAME + " TEXT," + TYPE + " TEXT," +
            CUISINE + " TEXT," + INGREDIENTS + " TEXT," + ALLERGENS + " TEXT," + PRICE + " TEXT," +  DESCRIPTION + " TEXT" + ")";

    public static final String CREATE_TABLE_ORDER = "CREATE TABLE " + DB_TABLE_ORDER + " (" +
            ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + CLIENT_ID + " TEXT," + COOK_ID + " TEXT," +
            MEAL_ID + " TEXT," + PICKUP_TIME + " TEXT," + STATUS + " TEXT" + ")";
    public static final String CREATE_TABLE_RATING = "CREATE TABLE " + DB_TABLE_RATING + " (" +
            ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COOK_ID + " TEXT," +
            MEAL_ID + " TEXT," + RATING + " TEXT" + ")";
    public static final String CREATE_TABLE_COMPLAIN = "CREATE TABLE " + DB_TABLE_COMPLAIN + " (" +
            ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + CLIENT_ID + " TEXT," +
            COOK_ID + " TEXT," + COMPLAIN + " TEXT" + ")";

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(CREATE_TABLE_CLIENT);
        sqLiteDatabase.execSQL(CREATE_TABLE_ADMIN);
        sqLiteDatabase.execSQL(CREATE_TABLE_COOK);
        sqLiteDatabase.execSQL(CREATE_TABLE_MEAL);
        sqLiteDatabase.execSQL(CREATE_TABLE_ORDER);
        sqLiteDatabase.execSQL(CREATE_TABLE_RATING);
        sqLiteDatabase.execSQL(CREATE_TABLE_COMPLAIN);

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + DB_TABLE_CLIENT);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + DB_TABLE_ADMIN);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + DB_TABLE_COOK);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + DB_TABLE_MEAL);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + DB_TABLE_ORDER);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + DB_TABLE_RATING);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + DB_TABLE_COMPLAIN);

        onCreate(sqLiteDatabase);
    }
    public void insertDataClient(String f_name,String l_name, String email,String pass,String address,String cc_info) {
        SQLiteDatabase sd = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(FIRST_NAME, f_name);
        cv.put(LAST_NAME, l_name);
        cv.put(EMAIL, email);
        cv.put(PASSWORD, pass);
        cv.put(ADDRESS, address);
        cv.put(CC_INFO, cc_info);
        sd.insert(DB_TABLE_CLIENT, null, cv);
    }
    public void insertDataAdmin(String email,String pass) {
        SQLiteDatabase sd = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(EMAIL, email);
        cv.put(PASSWORD, pass);
        sd.insert(DB_TABLE_ADMIN, null, cv);
    }
    public void insertDataCook(String f_name,String l_name, String email,String pass,String address,String desc,String cheque,String status) {

        SQLiteDatabase sd = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(FIRST_NAME, f_name);
        cv.put(LAST_NAME, l_name);
        cv.put(EMAIL, email);
        cv.put(PASSWORD, pass);
        cv.put(ADDRESS, address);
        cv.put(DESCRIPTION, desc);
        cv.put(CHEQUE, cheque);
        cv.put(STATUS, status);
        sd.insert(DB_TABLE_COOK, null, cv);
    }
    public void insertDataMeal(String cook_id, String name, String type,String cuisine, String ingredients,String allergens,String price,String desc) {

        SQLiteDatabase sd = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COOK_ID, cook_id);
        cv.put(NAME, name);
        cv.put(TYPE, type);
        cv.put(CUISINE, cuisine);
        cv.put(INGREDIENTS, ingredients);
        cv.put(ALLERGENS, allergens);
        cv.put(PRICE, price);
        cv.put(DESCRIPTION, desc);
        sd.insert(DB_TABLE_MEAL, null, cv);
    }
    public void insertDataOrder(String client_id, String cook_id, String meal_id, String pickup_time, String status) {
        SQLiteDatabase sd = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(CLIENT_ID, client_id);
        cv.put(COOK_ID, cook_id);
        cv.put(MEAL_ID, meal_id);
        cv.put(PICKUP_TIME, pickup_time);
        cv.put(STATUS, status);
        sd.insert(DB_TABLE_ORDER, null, cv);
    }

    public void updateOrderStatus(String id, String status) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(STATUS, status);

        db.update(DB_TABLE_ORDER, contentValues, "id = ?", new String[]{id});
    }
    public void insertDataComplain(String client_id,String cook_id, String complain) {
        SQLiteDatabase sd = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(CLIENT_ID, client_id);
        cv.put(COOK_ID, cook_id);
        cv.put(COMPLAIN, complain);
        sd.insert(DB_TABLE_COMPLAIN, null, cv);
    }
    public void insertDataRating(String cook_id,String meal_id, String rating) {
        SQLiteDatabase sd = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COOK_ID, cook_id);
        cv.put(MEAL_ID, meal_id);
        cv.put(RATING, rating);
        sd.insert(DB_TABLE_RATING, null, cv);
    }
    public Integer deleteDataMeal(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(DB_TABLE_MEAL, "id = ?", new String[]{id});
    }
    public Integer dismissComplain(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(DB_TABLE_COMPLAIN, "id = ?", new String[]{id});
    }
    public void suspendCook(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        String status = "Suspended";
        contentValues.put(STATUS, status);

        db.update(DB_TABLE_COOK, contentValues, "id = ?", new String[]{id});
    }
    public Cursor searchMeal(String text){
        SQLiteDatabase sd = this.getReadableDatabase();
        Cursor cursor = sd.rawQuery("select * from "+DB_TABLE_MEAL+" where name = ? or type = ? or cuisine = ?", new String[]{text, text, text});
        return cursor;
    }
    public Cursor cookLogin(String email, String password){
        SQLiteDatabase sd = this.getReadableDatabase();
        Cursor cursor = sd.rawQuery("select * from "+DB_TABLE_COOK+" where email = ? and password = ? limit 1", new String[]{email, password});
        return cursor;
    }
    public Cursor clientLogin(String email, String password){
        SQLiteDatabase sd = this.getReadableDatabase();
        Cursor cursor = sd.rawQuery("select * from "+DB_TABLE_CLIENT+" where email = ? and password = ? limit 1", new String[]{email, password});
        return cursor;
    }
    public Cursor searchCook(String id){
        SQLiteDatabase sd = this.getReadableDatabase();
        Cursor cursor = sd.rawQuery("select * from "+DB_TABLE_COOK+" where id = ?", new String[]{id});
        return cursor;
    }
    public Cursor viewMealsRequested(String id){
        SQLiteDatabase sd = this.getReadableDatabase();
        Cursor cursor = sd.rawQuery("select * from "+DB_TABLE_ORDER+" where client_id = ?", new String[]{id});
        return cursor;
    }
    public Cursor viewMealsPurchased(String id){
        SQLiteDatabase sd = this.getReadableDatabase();
        Cursor cursor = sd.rawQuery("select * from "+DB_TABLE_ORDER+" where client_id = ? and status = 'Approved'", new String[]{id});
        return cursor;
    }
    public Cursor viewCookOrders(String id){
        SQLiteDatabase sd = this.getReadableDatabase();
        Cursor cursor = sd.rawQuery("select * from "+DB_TABLE_ORDER+" where cook_id = ?", new String[]{id});
        return cursor;
    }
    public Cursor viewComplains(){
        SQLiteDatabase sd = this.getReadableDatabase();
        Cursor cursor = sd.rawQuery("select * from "+DB_TABLE_COMPLAIN, null);
        return cursor;
    }
    public Cursor viewCookMeals(String id){
        SQLiteDatabase sd = this.getReadableDatabase();
        Cursor cursor = sd.rawQuery("select * from "+DB_TABLE_MEAL+" where cook_id = ?", new String[]{id});
        return cursor;
    }
    public String getMealsSold(String id){
        SQLiteDatabase sd = this.getReadableDatabase();
        Cursor c = sd.rawQuery("select * from "+DB_TABLE_ORDER+" where cook_id = ?", new String[]{id});
        count = 0;
        if (c.getCount() > 0) {
            if (c.moveToFirst()) {
                do {
                    count = count + 1;

                } while (c.moveToNext());
            }
        }
        return Integer.toString(count);
    }
    public String getClientName(String id){
        SQLiteDatabase sd = this.getReadableDatabase();
        Cursor c = sd.rawQuery("select * from "+DB_TABLE_CLIENT+" where id = ?", new String[]{id});
        if (c.getCount() > 0) {
            if (c.moveToFirst()) {
                do {
                    name = c.getString(1);

                } while (c.moveToNext());
            }
        }
        return name;
    }
    public String getCookName(String id){
        SQLiteDatabase sd = this.getReadableDatabase();
        Cursor c = sd.rawQuery("select * from "+DB_TABLE_COOK+" where id = ?", new String[]{id});
        if (c.getCount() > 0) {
            if (c.moveToFirst()) {
                do {
                    name = c.getString(1);

                } while (c.moveToNext());
            }
        }
        return name;
    }
    public String getRating(String id){
        SQLiteDatabase sd = this.getReadableDatabase();

        Cursor c = sd.rawQuery("select * from "+DB_TABLE_RATING+" where cook_id = ?", new String[]{id});
        count = 0;
        rating = 0;
        if (c.getCount() > 0) {
            if (c.moveToFirst()) {
                do {
                    rating = rating + Integer.parseInt(c.getString(3));
                    count = count + 1;

                } while (c.moveToNext());
            }
        }else{
            rating = 0;
        }

        if(rating > 0){
            avg = rating / count;
        }else{
            avg = 0;
        }
        return Integer.toString(avg);
    }
}
