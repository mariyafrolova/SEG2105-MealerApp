package com.example.mealer;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;

public class CookOrdersActivity extends AppCompatActivity {
    RecyclerView rv;
    ArrayList<GetterSetterOrder> al;
    DatabaseHelper mydb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cook_orders);
        rv = findViewById(R.id.rev);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        rv.setLayoutManager(layoutManager);
        SharedPreferences sharedPrefUser = getSharedPreferences("cookData", MODE_PRIVATE);
        String cook_id = sharedPrefUser.getString("cook_id", "");
        viewData(cook_id);
    }
    private void viewData(String cook_id){
        mydb = new DatabaseHelper(getApplicationContext());
        al = new ArrayList<>();
        Cursor c = mydb.viewCookOrders(cook_id);
        if (c.getCount() > 0) {
            if (c.moveToFirst()) {
                do {

                    String id = c.getString(0);
                    String client_id = c.getString(1);
                    String meal_id = c.getString(3);
                    String pickup_time = c.getString(4);
                    String status = c.getString(5);

                    GetterSetterOrder gl = new GetterSetterOrder(id,client_id, cook_id, meal_id, pickup_time, status);
                    al.add(gl);

                } while (c.moveToNext());
            }
        }else{
            Toast.makeText(getApplicationContext(), "No meal ordered", Toast.LENGTH_SHORT).show();
        }
        CookOrdersAdapter my = new CookOrdersAdapter(getApplicationContext(), al);
        rv.setAdapter(my);
    }
}