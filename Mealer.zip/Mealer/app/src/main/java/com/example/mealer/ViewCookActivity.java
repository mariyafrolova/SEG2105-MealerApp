package com.example.mealer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class ViewCookActivity extends AppCompatActivity {
    TextView f_name, l_name, email, password, address, description, status;
    ImageView imageView;

    DatabaseHelper mydb;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_cook);
        f_name = findViewById(R.id.f_name);
        l_name = findViewById(R.id.l_name);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        address = findViewById(R.id.address);
        description = findViewById(R.id.description);
        status = findViewById(R.id.status);
        imageView = findViewById(R.id.imageView);

        mydb = new DatabaseHelper(this);
        SharedPreferences sharedPreforder = getSharedPreferences("viewCookData", MODE_PRIVATE);
        String cook_id = sharedPreforder.getString("cook_id", "");

        Cursor c = mydb.searchCook(cook_id);
        if (c.getCount() > 0) {
            if (c.moveToFirst()) {
                do {
                    f_name.setText("First Name: " + c.getString(1));
                    l_name.setText("Last Name: " + c.getString(2));
                    address.setText("Address: " + c.getString(5));
                    description.setText("Description: " + c.getString(6));
                    status.setText("Status: " + c.getString(8));
                    final byte[] decodedString = Base64.decode(c.getString(7), Base64.DEFAULT);
                    Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                    imageView.setImageBitmap(decodedByte);

                } while (c.moveToNext());
            }

        }
    }
}