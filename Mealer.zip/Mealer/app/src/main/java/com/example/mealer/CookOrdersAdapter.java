package com.example.mealer;

import static android.content.Context.MODE_PRIVATE;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CookOrdersAdapter extends RecyclerView.Adapter<CookOrdersAdapter.Myclass>{
    Context context;
    ArrayList<GetterSetterOrder> al;
    DatabaseHelper mydb;

    public CookOrdersAdapter(Context context, ArrayList<GetterSetterOrder> al){
        this.context = context;
        this.al = al;
    }
    @NonNull
    @Override
    public Myclass onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.rowfile_cook_orders,viewGroup,false);
        return new Myclass(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final Myclass myclass, int i) {
        final GetterSetterOrder gl = al.get(i);

        myclass.cook_id.setText("Cook Id: " + gl.getCook_id());
        myclass.meal_id.setText("Meal Id: " + gl.getMeal_id());
        myclass.pickup_time.setText("Pickup Time: " + gl.getPickup_time());
        myclass.status.setText("Status: " + gl.getStatus());

        myclass.approve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mydb = new DatabaseHelper(view.getContext());
                String status = "Approved";
                mydb.updateOrderStatus(gl.getId(), status);
                Toast.makeText(context, "Order Approved!", Toast.LENGTH_SHORT).show();
            }
        });
        myclass.reject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mydb = new DatabaseHelper(view.getContext());
                String status = "Rejected";
                mydb.updateOrderStatus(gl.getId(), status);
                Toast.makeText(context, "Order Rejected!", Toast.LENGTH_SHORT).show();
            }
        });


    }

    @Override
    public int getItemCount() {
        return al.size();
    }
    public class Myclass extends RecyclerView.ViewHolder{

        TextView cook_id,meal_id,pickup_time, status;
        Button approve, reject;
        View mview;

        public Myclass(@NonNull View itemView) {
            super(itemView);
            approve = itemView.findViewById(R.id.approve);
            reject = itemView.findViewById(R.id.reject);
            cook_id = itemView.findViewById(R.id.cook_id);
            meal_id  = itemView.findViewById(R.id.meal_id);
            pickup_time  = itemView.findViewById(R.id.pickup_time);
            status  = itemView.findViewById(R.id.status);
            mview = itemView;
        }
    }
}
