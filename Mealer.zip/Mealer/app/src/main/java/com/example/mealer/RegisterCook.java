package com.example.mealer;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class RegisterCook extends AppCompatActivity {
    EditText f_name, l_name, email, password, address, description;
    Button register;
    DatabaseHelper mydb;

    int REQUEST_CODE = 123;
    Bitmap bitmap;
    String bitmapUrl;
    Button chooseImage;
    String imageString;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_cook);
        f_name = findViewById(R.id.f_name);
        l_name = findViewById(R.id.l_name);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        address = findViewById(R.id.address);
        description = findViewById(R.id.description);
        register = findViewById(R.id.register);
        chooseImage = (Button) findViewById(R.id.chooseImage);
        imageView = (ImageView) findViewById(R.id.imageView);

        mydb = new DatabaseHelper(this);
        chooseImage.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                selectImage();
            }
        });

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String getFName = f_name.getText().toString();
                String getLName = l_name.getText().toString();
                String getEmail = email.getText().toString();
                String getPassword = password.getText().toString();
                String getAddress = address.getText().toString();
                String getDescription = description.getText().toString();
                try {
                    imageString = imageToString(bitmap);
                } catch (Exception e) {
                    imageString = "";
                }
                if (!getFName.equals("")){
                    if (!getLName.equals("")){
                        if (!getEmail.equals("")){
                            if (!getPassword.equals("")){
                                if (!getAddress.equals("")){
                                    if (!getDescription.equals("")){
                                        String status = "Active";
                                        mydb.insertDataCook(getFName,getLName, getEmail, getPassword, getAddress, getDescription, imageString, status);
                                        Toast.makeText(getApplicationContext(), "Cook Registered Successfully", Toast.LENGTH_SHORT).show();
                                        startActivity(new Intent(RegisterCook.this, MainActivity.class));

                                    }else{
                                        Toast.makeText(getApplicationContext(), "Credit Card Info cannot be empty!", Toast.LENGTH_SHORT).show();
                                    }

                                }else{
                                    Toast.makeText(getApplicationContext(), "Address cannot be empty!", Toast.LENGTH_SHORT).show();
                                }

                            }else{
                                Toast.makeText(getApplicationContext(), "Password cannot be empty!", Toast.LENGTH_SHORT).show();
                            }

                        }else{
                            Toast.makeText(getApplicationContext(), "Email cannot be empty!", Toast.LENGTH_SHORT).show();
                        }

                    }else{
                        Toast.makeText(getApplicationContext(), "Last Name cannot be empty!", Toast.LENGTH_SHORT).show();
                    }

                }else{
                    Toast.makeText(getApplicationContext(), "First Name cannot be empty!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    public void selectImage() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction("android.intent.action.GET_CONTENT");
        startActivityForResult(intent, this.REQUEST_CODE);
    }
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == this.REQUEST_CODE && resultCode == -1 && data != null) {
            try {
                this.bitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), data.getData());
                this.imageView.setImageBitmap(this.bitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    public String imageToString(Bitmap bitmap2) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap2.compress(Bitmap.CompressFormat.JPEG, 30, byteArrayOutputStream);
        return Base64.encodeToString(byteArrayOutputStream.toByteArray(), 0);
    }
}