package com.example.mealer;

public class GetterSetterOrder {
    String id;
    String client_id;
    String cook_id;
    String meal_id;
    String pickup_time;
    String status;

    public GetterSetterOrder(String id, String client_id, String cook_id, String meal_id, String pickup_time, String status) {
        this.id = id;
        this.client_id = client_id;
        this.cook_id = cook_id;
        this.meal_id = meal_id;
        this.pickup_time = pickup_time;
        this.status = status;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getClient_id() {
        return client_id;
    }

    public void setClient_id(String client_id) {
        this.client_id = client_id;
    }

    public String getCook_id() {
        return cook_id;
    }

    public void setCook_id(String cook_id) {
        this.cook_id = cook_id;
    }

    public String getMeal_id() {
        return meal_id;
    }

    public void setMeal_id(String meal_id) {
        this.meal_id = meal_id;
    }

    public String getPickup_time() {
        return pickup_time;
    }

    public void setPickup_time(String pickup_time) {
        this.pickup_time = pickup_time;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
