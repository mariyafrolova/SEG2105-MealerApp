package com.example.mealer;

public class GetterSetterComplain {
    String id;
    String client_id;
    String cook_id;
    String complain;

    public GetterSetterComplain(String id, String client_id, String cook_id, String complain) {
        this.id = id;
        this.client_id = client_id;
        this.cook_id = cook_id;
        this.complain = complain;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getClient_id() {
        return client_id;
    }

    public void setClient_id(String client_id) {
        this.client_id = client_id;
    }

    public String getCook_id() {
        return cook_id;
    }

    public void setCook_id(String cook_id) {
        this.cook_id = cook_id;
    }

    public String getComplain() {
        return complain;
    }

    public void setComplain(String complain) {
        this.complain = complain;
    }
}
