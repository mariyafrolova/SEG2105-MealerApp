package com.example.mealer;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CookMealAdapter extends RecyclerView.Adapter<CookMealAdapter.Myclass>{
    Context context;
    ArrayList<GetterSetterMeal> al;
    DatabaseHelper mydb;

    public CookMealAdapter(Context context, ArrayList<GetterSetterMeal> al){
        this.context = context;
        this.al = al;
    }
    @NonNull
    @Override
    public Myclass onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.rowfile_meal,viewGroup,false);
        return new Myclass(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final Myclass myclass, int i) {
        final GetterSetterMeal gl = al.get(i);

        myclass.name.setText("Meal Name: " + gl.getName());
        myclass.type.setText("Meal Type: " + gl.getType());
        myclass.cuisine.setText("Cuisine Type: " + gl.getCuisine());
        myclass.ingredients.setText("Ingredients: " + gl.getIngredient());
        myclass.allergens.setText("Allergens: " + gl.getAllergen());
        myclass.price.setText("Price: $"+gl.getPrice());
        myclass.description.setText("Description: " + gl.getDescription());



        myclass.remove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mydb = new DatabaseHelper(context);
                mydb.deleteDataMeal(gl.getId());
                Toast.makeText(context, "Meal removed successfully", Toast.LENGTH_SHORT).show();
            }
        });


    }

    @Override
    public int getItemCount() {
        return al.size();
    }
    public class Myclass extends RecyclerView.ViewHolder{

        TextView name,type,cuisine, ingredients, allergens, price, description;
        Button remove;
        View mview;

        public Myclass(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.name);
            type  = itemView.findViewById(R.id.type);
            cuisine  = itemView.findViewById(R.id.cuisine);
            ingredients  = itemView.findViewById(R.id.ingredients);
            allergens  = itemView.findViewById(R.id.allergens);
            price  = itemView.findViewById(R.id.price);
            description  = itemView.findViewById(R.id.description);
            remove  = itemView.findViewById(R.id.remove);
            mview = itemView;
        }
    }
}
