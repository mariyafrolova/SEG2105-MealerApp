package com.example.mealer;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class ClientHome extends AppCompatActivity {
    RecyclerView rv;
    ArrayList<GetterSetterMeal> al;
    DatabaseHelper mydb;
    EditText search;
    Button search_btn, meal_requested, meal_purchased;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client_home);
        search = findViewById(R.id.search);
        search_btn = findViewById(R.id.search_btn);
        meal_requested = findViewById(R.id.meal_requested);
        meal_purchased = findViewById(R.id.meal_purchased);
        rv = findViewById(R.id.rev);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        rv.setLayoutManager(layoutManager);

        search_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String getSearch = search.getText().toString();
                if (!getSearch.equals("")){
                    viewData(getSearch);
                }else{
                    Toast.makeText(getApplicationContext(), "Search entry is required!", Toast.LENGTH_SHORT).show();
                }
            }
        });
        meal_requested.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ClientHome.this, MealRequestsActivity.class));
            }
        });
        meal_purchased.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ClientHome.this, MealPurchasedActivity.class));
            }
        });
    }
    private void viewData(String search){
        al = new ArrayList<>();
        mydb = new DatabaseHelper(getApplicationContext());
        Cursor c = mydb.searchMeal(search);
        if (c.getCount() > 0) {
            if (c.moveToFirst()) {
                do {

                    String id = c.getString(0);
                    String c_id = c.getString(1);
                    String name = c.getString(2);
                    String type = c.getString(3);
                    String cuisine = c.getString(4);
                    String ingredient = c.getString(5);
                    String allergen = c.getString(6);
                    String price = c.getString(7);
                    String description = c.getString(8);

                    GetterSetterMeal gl = new GetterSetterMeal(id,c_id, name, type, cuisine, ingredient, allergen, price, description);
                    al.add(gl);

                } while (c.moveToNext());
            }
        }else{
            Toast.makeText(getApplicationContext(), "No meal found", Toast.LENGTH_SHORT).show();
        }
        ClientMealAdapter my = new ClientMealAdapter(getApplicationContext(), al);
        rv.setAdapter(my);
    }
}